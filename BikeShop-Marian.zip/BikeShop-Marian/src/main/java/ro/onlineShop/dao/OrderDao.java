package ro.onlineShop.dao;

import org.springframework.data.repository.CrudRepository;

public interface OrderDao extends CrudRepository<OrderCart, Integer> {
}
