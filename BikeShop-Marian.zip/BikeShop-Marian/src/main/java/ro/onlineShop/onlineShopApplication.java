package ro.onlineShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class onlineShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(onlineShopApplication.class, args);
	}

}
