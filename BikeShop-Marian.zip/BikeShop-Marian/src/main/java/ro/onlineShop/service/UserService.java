package ro.onlineShop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ro.onlineShop.dao.User;
import ro.onlineShop.dao.UserDao;
import ro.onlineShop.exceptions.UserException;

import java.util.List;

@Service
public class UserService {

    @Autowired
    UserDao userDao;

    public void save(String email, String password){
        User user = new User();
        user.setEmail(email);
        user.setPassword(password);
        userDao.save(user);
    }

    public void checkPassword(String password, String pasword2) throws UserException{
        if (!password.equals(pasword2)){
            throw new UserException("parolele nu sunt identice din exception");
        }
    }

    public List<User> getUsersByEmail(String email){

        return userDao.findByEmail(email);
    }
}
