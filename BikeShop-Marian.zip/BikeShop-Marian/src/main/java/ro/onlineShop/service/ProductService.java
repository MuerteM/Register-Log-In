package ro.onlineShop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ro.onlineShop.dao.Category;
import ro.onlineShop.dao.Product;
import ro.onlineShop.dao.ProductDao;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    ProductDao productDao;

    public List<Product> getAllProducts(){
        return (List<Product>) productDao.findAll();
    }

    public String addProduct(String name, Double price,
                             Integer quantity, String category){
        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        product.setQuantity(quantity);
        Category categoryProduct = new Category();
        categoryProduct.setName(category);
        product.setCategory(categoryProduct);
        productDao.save(product);
        return "produsul " + product.getName() + " a fost salvat";
    }

    public String removeProduct(Long id){
        productDao.deleteById(id);
        return "produsul a fost sters";
    }

    public Product findById(Long id){
        return productDao.findById(id).get();
    }
}
