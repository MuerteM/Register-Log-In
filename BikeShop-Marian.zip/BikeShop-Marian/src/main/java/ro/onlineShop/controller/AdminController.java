package ro.onlineShop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import ro.onlineShop.dao.Product;
import ro.onlineShop.service.ProductService;

import java.util.List;

@Controller
public class AdminController {

    @Autowired
    ProductService productService;

    @GetMapping("/admin/products")
    public ModelAndView viewProducts(){
        ModelAndView modelAndView =
                new ModelAndView("admin/products");
        List<Product> productList = productService.getAllProducts();
        modelAndView.addObject("products", productList);
        return  modelAndView;
    }

    @PostMapping("/admin/products")
    @ResponseBody
    public String addProduct(@RequestParam("name") String name,
                             @RequestParam("price") Double price,
                             @RequestParam("quantity") Integer quantity,
                             @RequestParam("category") String category
                             ){
        return productService.addProduct(name, price, quantity,category);
    }

    @DeleteMapping("/admin/products/{id}")
    @ResponseBody
    public String removeProduct(@PathVariable("id") Long id){
        return productService.removeProduct(id);
    }

}
