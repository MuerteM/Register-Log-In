package ro.onlineShop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import ro.onlineShop.dao.Category;
import ro.onlineShop.dao.Product;
import ro.onlineShop.dao.ProductDao;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ProductController {
    @Autowired
    ProductDao productDao;

    @GetMapping("/addProducts")
    @ResponseBody
    public List<Product> addProducts(){
        Category c1 = new Category();
        c1.setName("Biciclete");
        Category c2 = new Category();
        c2.setName("Accesorii");
        Category c3 = new Category();
        c3.setName("Protectii");
        Product p1 = new Product();
        p1.setCategory(c1);
        p1.setName("Mountain Bike Giant 2021");
        p1.setPrice(1600);
        p1.setQuantity(110);
        productDao.save(p1);
        Product p2 = new Product();
        p2.setName("Casca TSG Evolution");
        p2.setPrice(240);
        p2.setCategory(c2);
        p2.setQuantity(10);
        productDao.save(p2);
        Product p3 = new Product();
        p3.setName("Genunchere Leatt Knee Guard");
        p3.setPrice(300);
        p3.setCategory(c3);
        p3.setQuantity(14);
        productDao.save(p3);
        Product p4 = new Product();
        p4.setName("Cotiere Troy Lee");
        p4.setPrice(125);
        p4.setCategory(c3);
        p4.setQuantity(16);
        productDao.save(p4);

        List<Product> list = new ArrayList<>();
        list.add(p1);
        list.add(p2);
        list.add(p3);
        list.add(p4);
        return list;
    }

}
